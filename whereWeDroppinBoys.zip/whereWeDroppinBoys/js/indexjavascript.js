// var requestURL = 'https://api.fortnitetracker.com/v1/profile/pc/Ninja';
// var request = new XMLHttpRequest();

// request.open('GET', requestURL, "1fa1dc4-5e1c-43f7-8fb6-b73864fb3e95");
// request.responseType = 'json';
// request.send();


// var fortniteHeaders = new Headers();
// fortniteHeaders.append('TRN-Api-Key', "1fa1dc4-5e1c-43f7-8fb6-b73864fb3e95");

// let req = new Request(requestURL, {
// 	method: 'GET',
// 	headers: fortniteHeaders,
// 	mode: 'no-cors'
// });

// fetch(req)
//   .then(response => response.json())
//   .then(blob => {
//   	console.log(blob);
//     // myImage.src = URL.createObjectURL(blob);
//   });

//   //var platformSystem = $.("select#platforms").value();
//   //alert(platformSystem);

var SCOUT_API_CLIENTID = "cbed35ec-a27e-44e2-9ae5-fec6352c81d9";

  Scout.configure({
      clientId: SCOUT_API_CLIENTID
    }).then(() => {


    	alert("Is this point being hit?");
    async function asyncCall() {
        Scout.titles.list().then(titles => alert(JSON.parse(titles)))
        let search = await Scout.players.search("Ninja", "epic", null, "fortnite");
        let ninja = await Scout.players.get("fortnite", search.results[0].player.playerId);
        console.log("The Ninja result is " + JSON.stringify(ninja));
        }
    asyncCall();
    })
       


alert(.epic-nickname)